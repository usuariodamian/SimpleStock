﻿namespace Stock.Infrastructure
{
    public class SiteEnums
    {
        public enum Months : byte { Ene, Feb, Mar, Abr, May, Jun, Jul, Ago, Sep, Oct, Nov, Dic };
        public enum Roles
        {
            ADMIN,
            PAN,
            VEN
        }
    }
}
﻿namespace Stock.Infrastructure
{
    public class SiteConsts
    {
        public const string ProyectName = "Avícola San José";
        public const int RowMin = 50;
        public const int RowMid = 100;
        public const int RowMax = 200;
        public const string EntASJGuid = "18A0BF23-998E-4582-BCF9-7EAA882BD712";
        public const string EntRepGuid = "BA98B0DC-6DD6-4653-AF9D-208F2C9C2B05";
    }
}
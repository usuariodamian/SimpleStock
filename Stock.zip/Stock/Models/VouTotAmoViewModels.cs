﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Stock.Models
{
    public class VouTotAmoViewModels
    {
        [Required()]
        [Display(Name = "Entidad")]
        public Guid BusinessEntityId { get; set; }

        public List<VouTotAmoInf> InfList { get; set; }

        public VouTotAmoViewModels()
        {
            InfList = new List<VouTotAmoInf>();
        }
    }

    public class VouTotAmoInf
    {
        public Guid Id { get; set; }

        [Display(Name = "Fecha")]
        public DateTime VouDate { get; set; }

        [Display(Name = "Cent.Costo")]
        public string CostCenterName { get; set; }

        [Display(Name = "Número")]
        public string Number { get; set; }

        [Display(Name = "Descripción")]
        public string Description { get; set; }

        [Display(Name = "Ing.Fec.")]
        public DateTime InsertDate { get; set; }

        [Display(Name = "Ing.Usr.")]
        public string InsertUser { get; set; }

        [Display(Name = "Monto")]
        public decimal Amount { get; set; }

        public decimal Total { get; set; }
    }
}
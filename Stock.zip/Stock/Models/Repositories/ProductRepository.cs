using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Web;

namespace Stock.Models
{
    public class ProductRepository : IProductRepository
    {
        EFDbContext context = new EFDbContext();

        public IQueryable<Product> All
        {
            get { return context.Products; }
        }

        public IQueryable<Product> AllIncluding(params Expression<Func<Product, object>>[] includeProperties)
        {
            IQueryable<Product> query = context.Products;
            foreach (var includeProperty in includeProperties)
            {
                query = query.Include(includeProperty);
            }
            return query;
        }

        public Product Find(System.Guid id)
        {
            return context.Products.Find(id);
        }

        public void InsertOrUpdate(Product product)
        {
            if (product.Id == default(System.Guid))
            {
                // New entity
                product.InsertDate = DateTime.Now;
                product.Id = Guid.NewGuid();
                context.Products.Add(product);
            }
            else
            {
                // Existing entity
                product.UpdateDate = DateTime.Now;
                context.Entry(product).State = System.Data.Entity.EntityState.Modified;
            }
        }

        public void Delete(System.Guid id)
        {
            var product = context.Products.Find(id);
            context.Products.Remove(product);
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void Dispose()
        {
            context.Dispose();
        }

        #region Custom

        public bool HasRelationship(System.Guid id)
        {
            return context.Movements.Any(x => x.ProductId == id);
        }

        #endregion

        #region Information

        public Product sp_ProdAvesBlancasGet(DateTime DateNow)
        {
            SqlParameter pDateNow = new SqlParameter("@DateNow", DateNow);
            var parameters = new object[] { pDateNow };

            List<Product> result = context.Database.SqlQuery<Product>("sp_ProdAvesBlancasGet @DateNow", parameters).ToList();

            return result.FirstOrDefault();
        }

        #endregion
    }

    public interface IProductRepository : IDisposable
    {
        IQueryable<Product> All { get; }
        IQueryable<Product> AllIncluding(params Expression<Func<Product, object>>[] includeProperties);
        Product Find(System.Guid id);
        void InsertOrUpdate(Product product);
        void Delete(System.Guid id);
        void Save();

        bool HasRelationship(System.Guid id);
        Product sp_ProdAvesBlancasGet(DateTime DateNow);
    }
}
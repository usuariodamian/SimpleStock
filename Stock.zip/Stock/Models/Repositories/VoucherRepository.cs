using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using Stock.Infrastructure;

namespace Stock.Models
{
    public class VoucherRepository : IVoucherRepository
    {
        EFDbContext context = new EFDbContext();
        readonly Guid UserRep = new Guid(SiteConsts.EntRepGuid);

        public IQueryable<Voucher> All
        {
            get { return context.Vouchers; }
        }

        public IQueryable<Voucher> AllIncluding(params Expression<Func<Voucher, object>>[] includeProperties)
        {
            IQueryable<Voucher> query = context.Vouchers;
            foreach (var includeProperty in includeProperties)
            {
                query = query.Include(includeProperty);
            }
            return query;
        }

        public Voucher Find(System.Guid id)
        {
            return context.Vouchers.Find(id);
        }

        public void InsertOrUpdate(Voucher voucher)
        {
            if (voucher.Id == default(System.Guid))
            {
                voucher.InsertDate = DateTime.Now;
                voucher.Id = Guid.NewGuid();
                voucher.Active = true;
                context.Vouchers.Add(voucher);
            }
            else
            {
                voucher.UpdateDate = DateTime.Now;
                context.Entry(voucher).State = System.Data.Entity.EntityState.Modified;
            }
        }

        public void Delete(System.Guid id)
        {
            var voucher = context.Vouchers.Find(id);
            voucher.Active = false;
            //context.Vouchers.Remove(voucher);
            InsertOrUpdate(voucher);
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void Dispose()
        {
            context.Dispose();
        }

        #region Custom

        public List<Voucher> ReadByFilter(VouherViewModels vm)
        {
            var result = context.Vouchers.Where(x => x.Active && x.VouDate >= vm.DateFrom && x.VouDate <= vm.DateTo);
            if (vm.BusinessEntityId.HasValue)
                result = result.Where(x => x.BusinessEntityId == vm.BusinessEntityId);
            if (vm.CostCenterId.HasValue)
                result = result.Where(x => x.CostCenterId == vm.CostCenterId);
            if (!String.IsNullOrEmpty(vm.InsertUser))
                result = result.Where(x => x.InsertUser == vm.InsertUser);
            if (!String.IsNullOrEmpty(vm.Number))
                result = result.Where(x => x.Number.Contains(vm.Number.Trim()));

            return result.Take(SiteConsts.RowMin).OrderBy(x => x.VouDate).ToList();
        }

        public string GenerateAllVoucher(Guid costCenterId, String user)
        {
            var resp = sp_VouAllGenerate();
            int count = 0;
            foreach (var item in resp)
            {
                GenerateVoucher(item.Id, String.Empty, costCenterId, user);
                count++;
            }
            return $"Se generaron {count} comprobantes.";
        }

        public string GenerateVoucher(Guid id, String number, Guid costCenterId, String user)
        {
            if (UserRep == id)
                return "No se puede generar un comprobante para la entidad Repartidor.";

            var lMov = context.Movements.Where(m => m.Active && m.BusinessEntityId == id && !m.VoucherId.HasValue).AsNoTracking();
            if (lMov.Count() == 0)
                return "La entidad seleccionada no tiene ning�n movimiento para generar comprobante";

            if (number.Length > 50)
                number = number.Substring(0, 50);

            using (var dbTran = context.Database.BeginTransaction())
            {
                try
                {
                    decimal amount = 0;
                    foreach (var item in lMov)
                        amount += (item.Quantity * item.Price);

                    var voucher = new Voucher()
                    {
                        Id = Guid.NewGuid(),
                        InsertDate = DateTime.Now,
                        InsertUser = user,
                        VouDate = lMov.Min(d => d.MovDate),
                        BusinessEntityId = id,
                        Number = number,
                        Active = true,
                        Amount = amount,
                        CostCenterId = costCenterId
                    };
                    context.Vouchers.Add(voucher);
                    context.SaveChanges();

                    foreach (var item in lMov)
                    {
                        item.VoucherId = voucher.Id;
                        context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                    }
                    context.SaveChanges();

                    var be = context.BusinessEntities.Find(voucher.BusinessEntityId);
                    dbTran.Commit();

                    return $"Nuevo comprobante: {voucher.Number} {be.Name} {voucher.VouDate:dd/MM/yyyy} {voucher.Amount:F}";
                }
                catch (Exception ex)
                {
                    dbTran.Rollback();
                    return ex.Message;
                }
            }
        }

        /// <summary>
        /// Genera un contracomprobante
        /// </summary>
        /// <param name="id">voucher Id</param>
        /// <param name="amount">monto</param>
        /// <param name="user">usuario</param>
        /// <returns></returns>
        public string GenerateAgainstVoucher(Guid id, Decimal amount, String user)
        {
            amount = Math.Abs(amount);
            try
            {
                var or = context.Vouchers.FirstOrDefault(c => c.Active && c.Id == id);
                if (or is null)
                    return $"El comprobante no se puedo generar. El comprobante origen ha sido eliminado.";

                if (amount == 0)
                    amount = or.Amount;
                else
                    if (or.Amount < 0) amount = -1 * amount;

                var voucher = new Voucher()
                {
                    InsertDate = DateTime.Now,
                    InsertUser = user,
                    Id = Guid.NewGuid(),
                    Active = true,
                    BusinessEntityId = or.BusinessEntityId,
                    CostCenterId = or.CostCenterId,
                    VouDate = or.VouDate.AddMinutes(1),
                    Number = or.Number,
                    Amount = -1 * amount
                };
                context.Vouchers.Add(voucher);
                context.SaveChanges();
                var be = context.BusinessEntities.Find(voucher.BusinessEntityId);
                return $"Nuevo comprobante: {voucher.Number} {be.Name} {voucher.VouDate:dd/MM/yyyy} {voucher.Amount:F}";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string DeleteVoucher(Guid id, String user)
        {
            var lMov = context.Movements.Where(m => m.VoucherId == id);

            using (var dbTran = context.Database.BeginTransaction())
            {
                try
                {
                    var voucher = context.Vouchers.Find(id);
                    voucher.Active = false;
                    voucher.UpdateDate = DateTime.Now;
                    voucher.UpdateUser = user;
                    context.SaveChanges();

                    foreach (var item in lMov)
                    {
                        item.VoucherId = null;
                        context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                    }
                    context.SaveChanges();

                    var be = context.BusinessEntities.Find(voucher.BusinessEntityId);
                    dbTran.Commit();

                    return $"Se elimin� el comprobante para: {be.Name} {voucher.VouDate:dd/MM/yyyy} {voucher.Amount:F}";
                }
                catch (Exception ex)
                {
                    dbTran.Rollback();
                    return ex.Message;
                }
            }
        }

        public List<VouTotAmoInf> sp_VouTotalAmount(VouTotAmoViewModels vm)
        {
            SqlParameter Id = new SqlParameter("@Id", vm.BusinessEntityId);
            var parameters = new object[] { Id };

            List<VouTotAmoInf> result = context.Database.SqlQuery<VouTotAmoInf>("exec sp_VouTotalAmount @Id", parameters).OrderBy(o => o.VouDate).ToList();

            return result;
        }

        public List<VouDebtInf> sp_VouDebt()
        {
            return context.Database.SqlQuery<VouDebtInf>("exec sp_VouDebt").ToList();
        }

        public List<VouEntExiInf> sp_VouEntryExit(VouEntExiViewModels vm)
        {
            SqlParameter DateFrom = new SqlParameter("@DateFrom", vm.DateFrom);
            SqlParameter DateTo = new SqlParameter("@DateTo", vm.DateTo);
            var parameters = new object[] { DateFrom, DateTo };

            List<VouEntExiInf> result = context.Database.SqlQuery<VouEntExiInf>("exec sp_VouEntryExit @DateFrom, @DateTo", parameters).ToList();

            return result;
        }

        public decimal sp_VouEntryExitTotal(DateTime dt)
        {
            SqlParameter DateTo = new SqlParameter("@DateTo", dt);
            var parameters = new object[] { DateTo };

            decimal result = context.Database.SqlQuery<decimal>("exec sp_VouEntryExitTotal @DateTo", parameters).FirstOrDefault();

            return result;
        }

        public List<VouDebtInf> sp_VouAllGenerate()
        {
            return context.Database.SqlQuery<VouDebtInf>("exec sp_VouAllGenerate").ToList();
        }

        public List<VoucherInf> sp_Voucher(VouInfViewModels vm)
        {
            SqlParameter DateFrom = new SqlParameter("@DateFrom", vm.DateFrom);
            SqlParameter DateTo = new SqlParameter("@DateTo", vm.DateTo);
            SqlParameter BusinessEntityId = new SqlParameter("@BusinessEntityId", vm.BusinessEntityId);
            SqlParameter CostCenterId = new SqlParameter("@CostCenterId", vm.CostCenterId);

            var parameters = new object[] { DateFrom, DateTo, BusinessEntityId, CostCenterId };

            string sp = vm.IsEntry
                ? "exec sp_VouEntry @DateFrom, @DateTo, @BusinessEntityId, @CostCenterId"
                : "exec sp_VouExit @DateFrom, @DateTo, @BusinessEntityId, @CostCenterId";

            List<VoucherInf> result = context.Database.SqlQuery<VoucherInf>(sp, parameters).ToList();

            return result;
        }
        #endregion
    }

    public interface IVoucherRepository : IDisposable
    {
        IQueryable<Voucher> All { get; }
        IQueryable<Voucher> AllIncluding(params Expression<Func<Voucher, object>>[] includeProperties);
        Voucher Find(System.Guid id);
        void InsertOrUpdate(Voucher voucher);
        void Delete(System.Guid id);
        void Save();

        List<Voucher> ReadByFilter(VouherViewModels viewmodel);
        String GenerateVoucher(Guid id, String number, Guid costCenterId, String user);
        String GenerateAllVoucher(Guid costCenterId, String user);
        String GenerateAgainstVoucher(Guid id, Decimal amount, String user);
        String DeleteVoucher(Guid id, String user);
        List<VouTotAmoInf> sp_VouTotalAmount(VouTotAmoViewModels vm);
        List<VouDebtInf> sp_VouDebt();
        List<VouEntExiInf> sp_VouEntryExit(VouEntExiViewModels vm);
        decimal sp_VouEntryExitTotal(DateTime dt);
        List<VouDebtInf> sp_VouAllGenerate();
        List<VoucherInf> sp_Voucher(VouInfViewModels vm);
    }
}
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Web;

namespace Stock.Models
{ 
    public class CostCenterRepository : ICostCenterRepository
    {
        EFDbContext context = new EFDbContext();

        public IQueryable<CostCenter> All
        {
            get { return context.CostCenters; }
        }

        public IQueryable<CostCenter> AllIncluding(params Expression<Func<CostCenter, object>>[] includeProperties)
        {
            IQueryable<CostCenter> query = context.CostCenters;
            foreach (var includeProperty in includeProperties) {
                query = query.Include(includeProperty);
            }
            return query;
        }

        public List<CostCenter> AllCombo()
        {
            return context.CostCenters.AsNoTracking().OrderBy(_ => _.Name).ToList();
        }

        public CostCenter Find(Guid id)
        {
            return context.CostCenters.Find(id);
        }

        public void InsertOrUpdate(CostCenter costcenter)
        {
            if (costcenter.Id == default(Guid)) {
                // New entity
                costcenter.InsertDate = DateTime.Now;
                costcenter.Id = Guid.NewGuid();
                context.CostCenters.Add(costcenter);
            } else {
                // Existing entity
                costcenter.UpdateDate = DateTime.Now;
                context.Entry(costcenter).State = System.Data.Entity.EntityState.Modified;
            }
        }

        public void Delete(Guid id)
        {
            var costcenter = context.CostCenters.Find(id);
            context.CostCenters.Remove(costcenter);
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void Dispose() 
        {
            context.Dispose();
        }
    }

    public interface ICostCenterRepository : IDisposable
    {
        IQueryable<CostCenter> All { get; }
        IQueryable<CostCenter> AllIncluding(params Expression<Func<CostCenter, object>>[] includeProperties);
        CostCenter Find(Guid id);
        void InsertOrUpdate(CostCenter costcenter);
        void Delete(Guid id);
        void Save();

        List<CostCenter> AllCombo();
    }
}
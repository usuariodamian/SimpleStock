using Stock.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Stock.Models
{
    public class MovementRepository : IMovementRepository
    {
        EFDbContext context = new EFDbContext();
        readonly Guid UserRep = new Guid(SiteConsts.EntRepGuid);

        public IQueryable<Movement> All
        {
            get { return context.Movements; }
        }

        public IQueryable<Movement> AllIncluding(params Expression<Func<Movement, object>>[] includeProperties)
        {
            IQueryable<Movement> query = context.Movements;
            foreach (var includeProperty in includeProperties)
            {
                query = query.Include(includeProperty);
            }
            return query;
        }

        public Movement Find(System.Guid id)
        {
            return context.Movements.Find(id);
        }

        public void InsertOrUpdate(Movement movement)
        {
            if (movement.Id == default(System.Guid))
            {
                // New entity
                movement.InsertDate = DateTime.Now;
                movement.Id = Guid.NewGuid();
                context.Movements.Add(movement);
            }
            else
            {
                // Existing entity
                movement.UpdateDate = DateTime.Now;
                context.Entry(movement).State = System.Data.Entity.EntityState.Modified;
            }
        }

        public void Delete(System.Guid id)
        {
            var movement = context.Movements.Find(id);
            //context.Movements.Remove(movement);
            this.TransactionStock(movement);
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void Dispose()
        {
            context.Dispose();
        }

        #region Custom

        public async Task<List<Movement>> ReadByFilter(MovementViewModels viewmodel)
        {
            var result = context.Movements.Where(x => x.Active && x.MovDate >= viewmodel.DateFrom && x.MovDate <= viewmodel.DateTo && x.VoucherId.HasValue == viewmodel.HasVoucher);
            if (viewmodel.ProductId.HasValue)
                result = result.Where(x => x.ProductId == viewmodel.ProductId);
            if (viewmodel.BusinessEntityId.HasValue)
                result = result.Where(x => x.BusinessEntityId == viewmodel.BusinessEntityId);
            if (!String.IsNullOrEmpty(viewmodel.InsertUser))
                result = result.Where(x => x.InsertUser == viewmodel.InsertUser);

            return await result.Take(SiteConsts.RowMin).OrderBy(x => x.MovDate).ToListAsync();
        }

        public void TransactionStock(Movement movement)
        {
            using (var dbTran = context.Database.BeginTransaction())
            {
                try
                {
                    Product product = context.Products.Where(x => x.Id == movement.ProductId).FirstOrDefault();
                    product = GetRelated(product);

                    if (product != null)
                    {
                        if (movement.Id == default(System.Guid))
                        {
                            // Ingreso un movimiento
                            movement.InsertDate = DateTime.Now;
                            movement.Active = true;
                            movement.Id = Guid.NewGuid();
                            context.Movements.Add(movement);
                            if (UserRep != movement.BusinessEntityId)
                            {
                                product.Stock = product.Stock + movement.Quantity;
                                context.Entry(product).State = System.Data.Entity.EntityState.Modified;
                            }
                        }
                        else
                        {
                            // Elimino un movimiento
                            movement.UpdateDate = DateTime.Now;
                            movement.Active = false;
                            context.Entry(movement).State = System.Data.Entity.EntityState.Modified;
                            if (UserRep != movement.BusinessEntityId)
                            {
                                product.Stock = product.Stock - movement.Quantity;
                                context.Entry(product).State = System.Data.Entity.EntityState.Modified;
                            }
                        }
                        context.SaveChanges();
                        dbTran.Commit();
                    }
                }
                catch (Exception ex)
                {
                    dbTran.Rollback();
                }
            }
        }

        public List<Movement> ReadByVoucher(Guid id)
        {
            return context.Movements.Where(x => x.VoucherId == id).ToList();
        }

        #endregion

        #region Private
        /// <summary>
        /// Obtiene el producto relacionado para descontar stock
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        Product GetRelated(Product product)
        {
            int code = product.Code;
            if (code == 27) code = 22;
            if (code == 37) code = 32;
            if (code != product.Code)
                product = context.Products.Where(x => x.Code == code).FirstOrDefault();
            return product;
        }

        #endregion

        #region Information

        public List<MovStateInf> sp_MovStateInf(MovStateInfViewModels viewmodel)
        {
            SqlParameter DateFrom = new SqlParameter("@DateFrom", viewmodel.DateFrom);
            SqlParameter DateTo = new SqlParameter("@DateTo", viewmodel.DateTo);
            SqlParameter IsEntry = new SqlParameter("@IsEntry", viewmodel.IsEntry);
            var parameters = new object[] { DateFrom, DateTo, IsEntry };

            List<MovStateInf> result = context.Database.SqlQuery<MovStateInf>("sp_MovStateInf @DateFrom, @DateTo, @IsEntry", parameters).ToList();

            return result;
        }

        public MovStateInfViewModels MovStateInf(MovStateInfViewModels viewmodel)
        {
            // Validamos la cantidad de registros
            if ((viewmodel.DateTo - viewmodel.DateFrom).Days > SiteConsts.RowMax)
                viewmodel.DateTo = viewmodel.DateFrom.AddDays(SiteConsts.RowMax - 1);

            viewmodel.DateFrom = SiteMethods.GetDateFrom(viewmodel.DateFrom, null);
            viewmodel.DateTo = SiteMethods.GetDateTo(viewmodel.DateTo, null);

            List<MovStateInf> lMovStateInf = sp_MovStateInf(viewmodel);
            List<RowInf> lInfList = new List<RowInf>();

            DateTime StartDate = viewmodel.DateFrom;
            while (StartDate <= viewmodel.DateTo)
            {
                RowInf RowFinal = new RowInf();
                RowFinal.MovDate = StartDate;
                List<MovStateInf> lRow = lMovStateInf.Where(x => x.MovDate.Date == StartDate.Date).ToList();
                foreach (var item in lRow)
                {
                    switch (item.Code)
                    {
                        case 21:
                            RowFinal.B1 = item.SubTotal;
                            break;
                        case 22:
                            RowFinal.B2 = item.SubTotal;
                            break;
                        case 23:
                            RowFinal.B3 = item.SubTotal;
                            break;
                        case 24:
                            RowFinal.B4 = item.SubTotal;
                            break;
                        case 25:
                            // BLANCO JUMBO    25
                            RowFinal.BJ = item.SubTotal;
                            break;
                        case 26:
                            // BLANCO SUPER    26
                            RowFinal.BS = item.SubTotal;
                            break;
                        case 27:
                            // CAJA BLANCA 27
                            RowFinal.CB = item.SubTotal;
                            break;
                        case 31:
                            RowFinal.C1 = item.SubTotal;
                            break;
                        case 32:
                            RowFinal.C2 = item.SubTotal;
                            break;
                        case 33:
                            RowFinal.C3 = item.SubTotal;
                            break;
                        case 34:
                            RowFinal.C4 = item.SubTotal;
                            break;
                        case 35:
                            // COLOR JUMBO 35
                            RowFinal.CJ = item.SubTotal;
                            break;
                        case 36:
                            // COLOR SUPER 36
                            RowFinal.CS = item.SubTotal;
                            break;
                        case 37:
                            // CAJA COLOR  37
                            RowFinal.CC = item.SubTotal;
                            break;
                    }
                }
                lInfList.Add(RowFinal);
                StartDate = StartDate.AddDays(1);
            }
            viewmodel.InfList = lInfList;

            return viewmodel;
        }

        public List<MovDelInf> sp_MovDelivery(MovDelInfViewModels viewmodel)
        {
            SqlParameter DateFrom = new SqlParameter("@DateFrom", viewmodel.DateFrom);
            SqlParameter DateTo = new SqlParameter("@DateTo", viewmodel.DateTo);
            var parameters = new object[] { DateFrom, DateTo };

            List<MovDelInf> result = context.Database.SqlQuery<MovDelInf>("exec sp_MovDelivery @DateFrom, @DateTo", parameters).ToList();

            return result;
        }

        #endregion
    }

    public interface IMovementRepository : IDisposable
    {
        IQueryable<Movement> All { get; }
        IQueryable<Movement> AllIncluding(params Expression<Func<Movement, object>>[] includeProperties);
        Movement Find(System.Guid id);
        void InsertOrUpdate(Movement movement);
        void Delete(System.Guid id);
        void Save();

        void TransactionStock(Movement movement);
        Task<List<Movement>> ReadByFilter(MovementViewModels viewmodel);
        List<Movement> ReadByVoucher(Guid id);
        MovStateInfViewModels MovStateInf(MovStateInfViewModels viewmodel);
        List<MovDelInf> sp_MovDelivery(MovDelInfViewModels viewmodel);
    }
}
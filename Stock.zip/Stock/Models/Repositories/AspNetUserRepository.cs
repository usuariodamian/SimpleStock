﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;

namespace Stock.Models
{
    public class AspNetUserRepository : IAspNetUserRepository
    {
        EFDbContext context = new EFDbContext();

        public IQueryable<AspNetUser> All
        {
            get { return context.AspNetUsers; }
        }

        public IQueryable<AspNetUser> AllIncluding(params Expression<Func<AspNetUser, object>>[] includeProperties)
        {
            IQueryable<AspNetUser> query = context.AspNetUsers;
            foreach (var includeProperty in includeProperties)
            {
                query = query.Include(includeProperty);
            }
            return query;
        }

        public AspNetUser Find(string id)
        {
            return context.AspNetUsers.Find(id);
        }

        public void InsertOrUpdate(AspNetUser aspNetUser)
        {
            context.Entry(aspNetUser).State = System.Data.Entity.EntityState.Modified;
        }

        public void Delete(string id)
        {
            var aspNetUser = context.AspNetUsers.Find(id);
            context.AspNetUsers.Remove(aspNetUser);
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void Dispose()
        {
            context.Dispose();
        }
    }

    public interface IAspNetUserRepository : IDisposable
    {
        IQueryable<AspNetUser> All { get; }
        IQueryable<AspNetUser> AllIncluding(params Expression<Func<AspNetUser, object>>[] includeProperties);
        AspNetUser Find(string id);
        void InsertOrUpdate(AspNetUser aspNetUser);
        void Delete(string id);
        void Save();
    }
}
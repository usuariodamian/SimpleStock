﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.Identity.EntityFramework;

namespace Stock.Models
{
    public class RolRepository
    {
        EFDbContext context = new EFDbContext();

        public List<IdentityRole> All
        {
            get { return context.Roles.ToList(); }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Stock.Models
{
    public class UserRepository: IUserRepository
    {
        EFDbContext context = new EFDbContext();

        public List<ApplicationUser> All
        {
            get { return context.Users.ToList(); }
        }

        public ApplicationUser Find(string id)
        {
            return context.Users.Find(id);
        }

        public void InsertOrUpdate(ApplicationUser user)
        {
            context.Entry(user).State = System.Data.Entity.EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void Dispose()
        {
            var asd = context.Roles.ToList();
            context.Dispose();
        }
    }

    public interface IUserRepository: IDisposable
    {
        List<ApplicationUser> All { get; }
        ApplicationUser Find(string id);
        void InsertOrUpdate(ApplicationUser user);
        void Save();
    }
}
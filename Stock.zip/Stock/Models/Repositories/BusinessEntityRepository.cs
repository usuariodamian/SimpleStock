using Stock.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;

namespace Stock.Models
{ 
    public class BusinessEntityRepository : IBusinessEntityRepository
    {
        EFDbContext context = new EFDbContext();

        public IQueryable<BusinessEntity> All
        {
            get { return context.BusinessEntities; }
        }

        public IQueryable<BusinessEntity> AllIncluding(params Expression<Func<BusinessEntity, object>>[] includeProperties)
        {
            IQueryable<BusinessEntity> query = context.BusinessEntities;
            foreach (var includeProperty in includeProperties) {
                query = query.Include(includeProperty);
            }
            return query;
        }

        public BusinessEntity Find(System.Guid id)
        {
            return context.BusinessEntities.Find(id);
        }

        public void InsertOrUpdate(BusinessEntity businessentity)
        {
            if (businessentity.Id == default(System.Guid)) {
                // New entity
				businessentity.InsertDate = DateTime.Now;
                businessentity.Id = Guid.NewGuid();
                context.BusinessEntities.Add(businessentity);
            } else {
                // Existing entity
				businessentity.UpdateDate = DateTime.Now;
                context.Entry(businessentity).State = System.Data.Entity.EntityState.Modified;
            }
        }

        public void Delete(System.Guid id)
        {
            var businessentity = context.BusinessEntities.Find(id);
            context.BusinessEntities.Remove(businessentity);
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void Dispose() 
        {
            context.Dispose();
        }

        public List<BusinessEntity> AllByBEType(BusinessEntityType id)
        {
            return context.BusinessEntities.Where(_ => _.Active && (_.BEType == BusinessEntityType.Ambos || _.BEType == id)).OrderBy(_ => _.Name).ToList();
        }

        public List<BusinessEntity> ReadByFilter(BusEntViewModels vm)
        {
            var result = context.BusinessEntities.Where(x => x.Active == vm.Active);
            if (vm.BEType != 0)
                result = result.Where(x => x.BEType == vm.BEType);
            if (!String.IsNullOrEmpty(vm.Name))
                result = result.Where(x => x.Name.Contains(vm.Name.Trim()));

            return result.Take(SiteConsts.RowMin).OrderBy(x => x.Name).ToList();
        }
    }

    public interface IBusinessEntityRepository : IDisposable
    {
        IQueryable<BusinessEntity> All { get; }
        IQueryable<BusinessEntity> AllIncluding(params Expression<Func<BusinessEntity, object>>[] includeProperties);
        BusinessEntity Find(System.Guid id);
        void InsertOrUpdate(BusinessEntity businessentity);
        void Delete(System.Guid id);
        void Save();

        List<BusinessEntity> AllByBEType(BusinessEntityType id);
        List<BusinessEntity> ReadByFilter(BusEntViewModels vm);
    }
}
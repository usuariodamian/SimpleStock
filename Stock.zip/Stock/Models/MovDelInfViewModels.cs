﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Stock.Models
{
    public class MovDelInfViewModels
	{
        [Required]
        [Display(Name = "Desde")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateFrom { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime HrFrom { get; set; }

        [Required]
        [Display(Name = "Hasta")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateTo { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime HrTo { get; set; }

        public List<MovDelInf> InfList { get; set; }
        public MovDelInfViewModels()
        {
            // en el contructor tenemos que inicializar la lista
            InfList = new List<MovDelInf>();
        }
    }

    public class MovDelInf
    {
        public Guid ProductId { get; set; }
        [Display(Name = "Descripción")]
        public string Description { get; set; }
        [Display(Name = "Entrada")]
        public decimal SubTotalEntry { get; set; }
        [Display(Name = "Salida")]
        public decimal SubTotalExit { get; set; }
        public decimal SubTotal { get; set; }
    }
}
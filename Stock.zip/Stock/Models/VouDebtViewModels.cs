﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Stock.Models
{
	public class VouDebtViewModels
    {
        public List<VouDebtInf> InfList { get; set; }

        public decimal TotalEntry => InfList.Where(x => x.BEType == BusinessEntityType.Cliente).Sum(x => x.Total);
        public decimal TotalExit => InfList.Where(x => x.BEType == BusinessEntityType.Proveedor).Sum(x => x.Total);

        public VouDebtViewModels()
        {
            InfList = new List<VouDebtInf>();
        }
    }

    public class VouDebtInf
    {
        public Guid Id { get; set; }
        [Display(Name = "Tipo")]
        public BusinessEntityType BEType { get; set; }
        [Display(Name = "Entidad")]
        public string Name { get; set; }
        [Display(Name = "Teléfono")]
        public string Phone { get; set; }
        [Display(Name = "Descripción")]
        public string Description { get; set; }

        public decimal Total { get; set; }
    }
}
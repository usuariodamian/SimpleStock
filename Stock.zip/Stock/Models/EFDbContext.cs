using System.Data.Entity;

namespace Stock.Models
{
    public class EFDbContext : ApplicationDbContext
    {
        // You can add custom code to this file. Changes will not be overwritten.
        // DbContext or ApplicationDbContext
        // If you want Entity Framework to drop and regenerate your database
        // automatically whenever you change your model schema, add the following
        // code to the Application_Start method in your Global.asax file.
        // Note: this will destroy and re-create your database with every model change.
        // 
        // System.Data.Entity.Database.SetInitializer(new System.Data.Entity.DropCreateDatabaseIfModelChanges<Stock.Models.EFDbContext>());

        public DbSet<Stock.Models.Product> Products { get; set; }

        public DbSet<Stock.Models.Movement> Movements { get; set; }

        public DbSet<Stock.Models.BusinessEntity> BusinessEntities { get; set; }

        public DbSet<Stock.Models.Voucher> Vouchers { get; set; }

        public DbSet<Stock.Models.CostCenter> CostCenters { get; set; }
    }
}
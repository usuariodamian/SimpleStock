﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Stock.Models
{
    public class VouEntExiViewModels
    {
        [Required]
        [Display(Name = "Desde")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateFrom { get; set; }

        [Required]
        [Display(Name = "Hasta")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateTo { get; set; }

        [Display(Name = "Saldo anterior")]
        public bool PreviousBalance { get; set; }

        public List<VouEntExiInf> InfList { get; set; }
        public VouEntExiViewModels()
        {
            // en el contructor tenemos que inicializar la lista
            InfList = new List<VouEntExiInf>();
        }
    }

    public class VouEntExiInf
    {
        public Guid Id { get; set; }
        public Guid BusinessEntityId { get; set; }
        [Display(Name = "Fecha")]
        public DateTime VouDate { get; set; }
        [Display(Name = "Entidad")]
        public string BusinessEntity { get; set; }
        [Display(Name = "Cent.Costo")]
        public string CostCenter { get; set; }
        [Display(Name = "Número")]
        public string Number { get; set; }
        [Display(Name = "Ing.Usr.")]
        public string InsertUser { get; set; }
        public decimal Amount { get; set; }

        [NotMapped]
        [Display(Name = "Ingreso")]
        public decimal Entry => Amount >= 0 ? Amount : 0;
        [NotMapped]
        [Display(Name = "Egreso")]
        public decimal Exit => Amount < 0 ? Amount : 0;
        [NotMapped]
        public decimal SubTotal { get; set; }
    }
}
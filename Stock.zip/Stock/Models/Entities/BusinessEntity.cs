﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Stock.Models
{
    [Serializable]
    public class BusinessEntity
    {
        [Key]
        public Guid Id { get; set; }
        [Timestamp]
        public byte[] Timestamp { get; set; }
        [Display(Name = "Ing.Fec.")]
        public DateTime? InsertDate { get; set; }
        [Display(Name = "Ing.Usr.")]
        public string InsertUser { get; set; }
        [Display(Name = "Edit.Fec.")]
        public DateTime? UpdateDate { get; set; }
        [Display(Name = "Edit.Usr.")]
        public string UpdateUser { get; set; }

        [Required()]
        [Display(Name = "Tipo")]
        public BusinessEntityType BEType { get; set; }

        [Required()]
        [Display(Name = "Nombre")]
        [MaxLength(50, ErrorMessage = "Máximo 50 caracteres")]
        public string Name { get; set; }

        [Required()]
        [Display(Name = "CUIT")]
        [MaxLength(20, ErrorMessage = "Máximo 20 caracteres")]
        public string CUIT { get; set; }

        [Display(Name = "Descripción"), DataType(DataType.MultilineText)]
        [MaxLength(100, ErrorMessage = "Máximo 100 caracteres")]
        public string Description { get; set; }

        [Display(Name = "Teléfono")]
        [MaxLength(50, ErrorMessage = "Máximo 50 caracteres")]
        public string Phone { get; set; }

        [Display(Name = "Email")]
        [MaxLength(128, ErrorMessage = "Máximo 128 caracteres")]
        public string Email { get; set; }

        [Required()]
        [Display(Name = "Activo")]
        public bool Active { get; set; }

        [Display(Name = "Dirección"), DataType(DataType.MultilineText)]
        [MaxLength(128, ErrorMessage = "Máximo 128 caracteres")]
        public string Address { get; set; }
    }

    public enum BusinessEntityType
    {
        Ambos = 1,
        Proveedor = 2,
        Cliente = 3
    }
}
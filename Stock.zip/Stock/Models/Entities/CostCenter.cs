using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.ComponentModel;

namespace Stock.Models
{
    [Serializable]
    public partial class CostCenter
    {
        public virtual ICollection<Voucher> Vouchers { get; set; }

        [Key]
        public Guid Id { get; set; }
        [Timestamp]
        public byte[] Timestamp { get; set; }
        public DateTime? InsertDate { get; set; }
        public string InsertUser { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string UpdateUser { get; set; }
        
        [Required()]
        [MaxLength(50,ErrorMessage ="M�ximo 50 caracteres")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }
    }
}
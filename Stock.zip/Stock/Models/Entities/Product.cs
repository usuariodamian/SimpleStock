using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Stock.Models
{
    [Serializable]
    public partial class Product
    {
        public virtual ICollection<Movement> Movements { get; set; }

        [Key]
        public Guid Id { get; set; }
        [Timestamp]
        public byte[] Timestamp { get; set; }
        [Display(Name = "Ing.Fec.")]
        public DateTime? InsertDate { get; set; }
        [Display(Name = "Ing.Usr.")]
        public string InsertUser { get; set; }
        [Display(Name = "Edit.Fec.")]
        public DateTime? UpdateDate { get; set; }
        [Display(Name = "Edit.Usr.")]
        public string UpdateUser { get; set; }

        [Required()]
        [MaxLength(50, ErrorMessage = "M�ximo 50 caracteres")]
        [Display(Name = "Descripci�n")]
        public string Description { get; set; }

        [Display(Name = "Stock"), DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:F}")]
        public decimal Stock { get; set; }

        [Range(1, 999999999, ErrorMessage = "Ingrese un n�mero entre 1 y 999999999")]
        [Display(Name = "C�digo")]
        public int Code { get; set; }

        [Range(0, 999999999, ErrorMessage = "Ingrese un n�mero entre 0 y 999999999")]
        [Display(Name = "Precio")]
        public decimal Price { get; set; }

        [NotMapped]
        [Display(Name = "Cajones")]
        public string Boxs => Code >= 20 && Code < 40 ? string.Format("{0} / {1:0}", Math.Truncate(Stock / 12), Stock - Math.Truncate(Stock / 12) * 12) : string.Empty;
    }
}
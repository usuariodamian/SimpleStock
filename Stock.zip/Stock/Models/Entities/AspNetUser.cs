using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Stock.Models
{
    public partial class AspNetUser
    {
        #region Identity Server

        [Required]
        [Key]
        public string Id { get; set; }

        [Required]
        [Display(Name = "Correo")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "Confirmar Correo")]
        public bool EmailConfirmed { get; set; }

        [Display(Name = "Contrase�a")]
        public string PasswordHash { get; set; }

        [Display(Name = "Seguridad")]
        public string SecurityStamp { get; set; }

        [Display(Name = "Tel�fono")]
        public string PhoneNumber { get; set; }

        [Required]
        [Display(Name = "Confirmar Tel�fono")]
        public bool PhoneNumberConfirmed { get; set; }

        [Required]
        [Display(Name = "Dos factores habilitados")]
        public bool TwoFactorEnabled { get; set; }

        [Display(Name = "Finalizaci�n de bloqueo Utc")]
        public DateTime? LockoutEndDateUtc { get; set; }

        [Required]
        [Display(Name = "Bloqueo habilitado")]
        public bool LockoutEnabled { get; set; }

        [Required]
        [Display(Name = "Cantidad de Accesos Fallidos")]
        public int AccessFailedCount { get; set; }

        [Required]
        [Display(Name = "Usuario")]
        public string UserName { get; set; }

        #endregion

        [Required]
        [Display(Name = "Estado")]
        public AspNetUserState State { get; set; }

    }

}
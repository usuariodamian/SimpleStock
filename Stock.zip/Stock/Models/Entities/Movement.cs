using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations.Schema;

namespace Stock.Models
{
    [Serializable]
    public partial class Movement
    {
        [Key]
        public Guid Id { get; set; }
        [Timestamp]
        public byte[] Timestamp { get; set; }
        public DateTime? InsertDate { get; set; }
        [Display(Name = "Ins.Usr.")]
        public string InsertUser { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string UpdateUser { get; set; }

        [Required()]
        //[ForeignKey("Product")]
        [Display(Name = "Producto")]
        public Guid ProductId { get; set; }
        public virtual Product Product { get; set; }

        [Required()]
        //[ForeignKey("BusinessEntity")]
        [Display(Name = "Entidad")]
        public Guid BusinessEntityId { get; set; }
        public virtual BusinessEntity BusinessEntity { get; set; }

        [Required()]
        [Range(-999999999, 999999999)]
        [DisplayFormat(DataFormatString = "{0:#.##}", ApplyFormatInEditMode = true)]
        [Display(Name = "Cantidad")]
        public decimal Quantity { get; set; }

        [Display(Name = "Descripci�n")]
        [MaxLength(128), DataType(DataType.MultilineText)]
        public string Description { get; set; }

        [Required()]
        [DataType(DataType.DateTime)]
        [DisplayFormat(ApplyFormatInEditMode = true, ConvertEmptyStringToNull = false, DataFormatString = "{0:dd/MM/yyyy HH:mm}")]
        [Display(Name = "Fecha")]
        public DateTime MovDate { get; set; }

        [Display(Name = "Activo")]
        public bool Active { get; set; }

        public Guid? VoucherId { get; set; }
        public virtual Voucher Voucher { get; set; }

        [Required()]
        [Range(0, 999999999)]
        [DisplayFormat(DataFormatString = "{0:#.##}", ApplyFormatInEditMode = true)]
        [Display(Name = "Precio")]
        public decimal Price { get; set; }

        [NotMapped]
        public bool IsIn { get; set; }

        [NotMapped]
        public decimal Subtotal => Quantity * Price;

    }
}
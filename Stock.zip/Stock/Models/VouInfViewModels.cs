﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Stock.Models
{
    public class VouInfViewModels
    {
        [Required]
        [Display(Name = "Desde")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateFrom { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime HrFrom { get; set; }

        [Required]
        [Display(Name = "Hasta")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateTo { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime HrTo { get; set; }

        [Display(Name = "Entidad")]
        public Guid? BusinessEntityId { get; set; }

        [Display(Name = "Cent.Costo")]
        public Guid? CostCenterId { get; set; }

        [Display(Name = "Ingreso")]
        public bool IsEntry { get; set; }

        public List<VoucherInf> ListVoucher { get; set; }
        public VouInfViewModels()
        {
            // en el contructor tenemos que inicializar la lista
            ListVoucher = new List<VoucherInf>();
        }
    }

    public class VoucherInf
    {
        [Key]
        public Guid Id { get; set; }
        [Timestamp]
        public byte[] Timestamp { get; set; }
        [Display(Name = "Ing.Fec.")]
        public DateTime? InsertDate { get; set; }
        [Display(Name = "Ing.Usr.")]
        public string InsertUser { get; set; }
        [Display(Name = "Edit.Fec.")]
        public DateTime? UpdateDate { get; set; }
        [Display(Name = "Edit.Usr.")]
        public string UpdateUser { get; set; }

        [Required()]
        [DataType(DataType.DateTime)]
        [DisplayFormat(ApplyFormatInEditMode = true, ConvertEmptyStringToNull = false, DataFormatString = "{0:dd/MM/yyyy HH:mm}")]
        [Display(Name = "Fecha")]
        public DateTime VouDate { get; set; }

        //[Required()]
        //[ForeignKey("BusinessEntity")]
        //[Display(Name = "Entidad")]
        //public Guid BusinessEntityId { get; set; }
        //public virtual BusinessEntity BusinessEntity { get; set; }

        [StringLength(50)]
        [Display(Name = "Número")]
        public string Number { get; set; }

        [Display(Name = "Descripción")]
        [MaxLength(128), DataType(DataType.MultilineText)]
        public string Description { get; set; }

        [Required()]
        [Range(-999999999, 999999999)]
        [DisplayFormat(DataFormatString = "{0:#.##}", ApplyFormatInEditMode = true)]
        [Display(Name = "Monto")]
        public decimal Amount { get; set; }

        [Display(Name = "Activo")]
        public bool Active { get; set; }

        //[Required()]
        //[ForeignKey("CostCenter")]
        //[Display(Name = "Cent.Costo")]
        //public Guid CostCenterId { get; set; }
        //public virtual CostCenter CostCenter { get; set; }
        
        //news
        [Display(Name = "Entidad")]
        public string BusinessEntity { get; set; }
        [Display(Name = "Cent.Costo")]
        public string CostCenter { get; set; }
    }
}
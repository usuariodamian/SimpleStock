﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Stock.Models
{
    public class BusEntViewModels
    {
        [Display(Name = "Tipo")]
        public BusinessEntityType BEType { get; set; }

        [Display(Name = "Nombre")]
        [MaxLength(50, ErrorMessage = "Máximo 50 caracteres")]
        public string Name { get; set; }

        [Required()]
        [Display(Name = "Activo")]
        public bool Active { get; set; }

        public List<BusinessEntity> List { get; set; }
        public BusEntViewModels() { List = new List<BusinessEntity>(); }
    }
}
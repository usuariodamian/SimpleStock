﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Stock.Models
{
    public class MovStateInfViewModels
    {
        [Required]
        [Display(Name = "Desde")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateFrom { get; set; }
        [Required]
        [Display(Name = "Hasta")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateTo { get; set; }
        [Required()]
        [Display(Name = "Ingreso")]
        public bool IsEntry { get; set; }

        public List<RowInf> InfList { get; set; }

        public MovStateInfViewModels()
        {
            InfList = new List<RowInf>();
        }
    }

    public class MovStateInf
    {
        public Guid Id { get; set; }

        [Display(Name = "Descripción")]
        public string Description { get; set; }

        [Range(1, 999999999, ErrorMessage = "Ingrese un número entre 1 y 999999999")]
        [Display(Name = "Código")]
        public int Code { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime MovDate { get; set; }

        public decimal SubTotal { get; set; }
    }

    public class RowInf
    {
        public DateTime MovDate { get; set; }
        // Blanco
        [DefaultValue(0)]
        public decimal B1 { get; set; }
        [DefaultValue(0)]
        public decimal B2 { get; set; }
        [DefaultValue(0)]
        public decimal B3 { get; set; }
        [DefaultValue(0)]
        public decimal B4 { get; set; }
        [DefaultValue(0)]
        public decimal BJ { get; set; }
        [DefaultValue(0)]
        public decimal BS { get; set; }
        // Color
        [DefaultValue(0)]
        public decimal C1 { get; set; }
        [DefaultValue(0)]
        public decimal C2 { get; set; }
        [DefaultValue(0)]
        public decimal C3 { get; set; }
        [DefaultValue(0)]
        public decimal C4 { get; set; }
        [DefaultValue(0)]
        public decimal CJ { get; set; }
        [DefaultValue(0)]
        public decimal CS { get; set; }
        // Caja
        [DefaultValue(0)]
        public decimal CB { get; set; }
        [DefaultValue(0)]
        public decimal CC { get; set; }
    }
}
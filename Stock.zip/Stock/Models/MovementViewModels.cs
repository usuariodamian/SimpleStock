﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Stock.Models
{
    public class MovementViewModels
    {
        [Required]
        [Display(Name = "Desde")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateFrom { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime HrFrom { get; set; }

        [Required]
        [Display(Name = "Hasta")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateTo { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime HrTo { get; set; }

        [Display(Name = "Producto")]
        public Guid? ProductId { get; set; }

        [Display(Name = "Entidad")]
        public Guid? BusinessEntityId { get; set; }

        [Display(Name = "Usuario")]
        public string InsertUser { get; set; }

        [Display(Name = "Compr.")]
        public bool HasVoucher { get; set; }

        [Display(Name = "Cent.Costo")]
        public Guid CostCenterId { get; set; }

        public List<Movement> ListMovement { get; set; }
        public MovementViewModels()
        {
            // en el contructor tenemos que inicializar la lista
            ListMovement = new List<Movement>();
        }
    }

    /// <summary>
    /// TODO: probar si funciona sacando Ajax
    /// </summary>
    public class ValidDateMovement : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (Models.MovementViewModels)validationContext.ObjectInstance;
            DateTime DateFrom = Convert.ToDateTime(value);
            DateTime DateTo = Convert.ToDateTime(model.DateTo);

            if (DateFrom > DateTo)
            {
                return new ValidationResult("La Fecha Desde es mayor que la Fecha Hasta.");
            }
            else
            {
                TimeSpan dif = DateTo - DateFrom;
                if (dif.TotalDays > 60)
                    return new ValidationResult("La diferecia de días no puede ser mayor a 60.");
                else
                    return ValidationResult.Success;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Stock.Models
{
    public class VouherViewModels
    {
        [Required]
        [Display(Name = "Desde")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateFrom { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime HrFrom { get; set; }

        [Required]
        [Display(Name = "Hasta")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateTo { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime HrTo { get; set; }

        [Display(Name = "Entidad")]
        public Guid? BusinessEntityId { get; set; }

        [Display(Name = "Cent.Costo")]
        public Guid? CostCenterId { get; set; }

        [Display(Name = "Usuario")]
        public string InsertUser { get; set; }

        [StringLength(50)]
        [Display(Name = "Número")]
        public string Number { get; set; }

        public List<Voucher> ListVoucher { get; set; }
        public VouherViewModels()
        {
            // en el contructor tenemos que inicializar la lista
            ListVoucher = new List<Voucher>();
        }
    }
}
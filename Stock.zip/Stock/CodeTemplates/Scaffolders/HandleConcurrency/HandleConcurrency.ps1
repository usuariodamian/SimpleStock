[T4Scaffolding.Scaffolder(Description = "Enter a description of HandleConcurrency here")][CmdletBinding()]
param(        
    [string]$Project,
	[string]$CodeLanguage,
	[string[]]$TemplateFolders,
	[switch]$Force = $false
)
Write-Host "Agregue la siquiente linea filters.Add(new HandleConcurrencyExceptionAttribute()); en FilterConfig.RegisterGlobalFilters" -ForegroundColor Blue

$outputPath = "Infrastructure\HandleConcurrencyExceptionAttribute"
$namespace = (Get-Project $Project).Properties.Item("DefaultNamespace").Value + ".Infrastructure"

Add-ProjectItemViaTemplate $outputPath -Template HandleConcurrencyTemplate `
	-Model @{ Namespace = $namespace; ExampleValue = "Hello, world!" } `
	-SuccessMessage "Added HandleConcurrency output at {0}" `
	-TemplateFolders $TemplateFolders -Project $Project -CodeLanguage $CodeLanguage -Force:$Force
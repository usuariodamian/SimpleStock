[T4Scaffolding.Scaffolder(Description = "Enter a description of AddClass here")][CmdletBinding()]
param(        
    [parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $true)][string]$ModelType,
	[string]$Project,
	[string]$CodeLanguage,
	[string[]]$TemplateFolders,
	[switch]$Force = $false
)

$outputPath = "Models\Entities\" + $ModelType
$namespace = (Get-Project $Project).Properties.Item("DefaultNamespace").Value + ".Models"

Add-ProjectItemViaTemplate $outputPath -Template AddClassTemplate `
	-Model @{ Namespace = $namespace; ClassName = $ModelType; ExampleValue = "Hello, world!" } `
	-SuccessMessage "Added AddClass output at {0}" `
	-TemplateFolders $TemplateFolders -Project $Project -CodeLanguage $CodeLanguage -Force:$Force

try{
	$file = Get-ProjectItem "$($outputPath).cs" -Project $coreProjectName
	$file.Open()
	$file.Document.Activate()	
	$DTE.ExecuteCommand("Edit.FormatDocument", "")
	$DTE.ActiveDocument.Save()
}catch {
	#Write-Host "Hey, you better not be clicking around in VS while we generate code" -ForegroundColor DarkRed
}
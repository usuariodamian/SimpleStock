﻿using Stock.Infrastructure;
using System.Web;
using System.Web.Mvc;

namespace Stock
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
            filters.Add(new HandleConcurrencyExceptionAttribute());
            //By default, all actions require a logged in user
            //filters.Add(new AuthorizeAttribute());
        }
    }
}

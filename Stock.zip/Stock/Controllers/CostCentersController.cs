//using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Stock.Models;

namespace Stock.Controllers
{
    [Authorize(Roles = "ADMIN,DUE")]
    public class CostCentersController : Controller
    {
		private readonly ICostCenterRepository costcenterRepository;

		// If you are using Dependency Injection, you can delete the following constructor
        public CostCentersController() : this(new CostCenterRepository())
        {
        }

        public CostCentersController(ICostCenterRepository costcenterRepository)
        {
			this.costcenterRepository = costcenterRepository;
        }

        //
        // GET: /CostCenters/

        public ViewResult Index()
        {
            return View(costcenterRepository.All.OrderBy(c=> c.Name));
        }

        //
        // GET: /CostCenters/Details/5

        public ViewResult Details(Guid id)
        {
            return View(costcenterRepository.Find(id));
        }

        //
        // GET: /CostCenters/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /CostCenters/Create

        [HttpPost]
        public ActionResult Create(CostCenter costcenter)
        {
            if (ModelState.IsValid) {
				costcenter.InsertUser = User.Identity.Name;
                costcenterRepository.InsertOrUpdate(costcenter);
                costcenterRepository.Save();
                return RedirectToAction("Index");
            } else {
				return View();
			}
        }
        
        //
        // GET: /CostCenters/Edit/5
 
        public ActionResult Edit(Guid id)
        {
             return View(costcenterRepository.Find(id));
        }

        //
        // POST: /CostCenters/Edit/5

        [HttpPost]
        public ActionResult Edit(CostCenter costcenter)
        {
            if (ModelState.IsValid) {
                costcenter.UpdateUser = User.Identity.Name;
                costcenterRepository.InsertOrUpdate(costcenter);
                costcenterRepository.Save();
                return RedirectToAction("Index");
            } else {
				return View();
			}
        }

        //
        // GET: /CostCenters/Delete/5
 
        public ActionResult Delete(Guid id)
        {
            return View(costcenterRepository.Find(id));
        }

        //
        // POST: /CostCenters/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(Guid id)
        {
            costcenterRepository.Delete(id);
            costcenterRepository.Save();

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) {
                costcenterRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}


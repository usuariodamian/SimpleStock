﻿using Stock.Infrastructure;
using Stock.Models;
using System;
using System.Web.Mvc;

namespace Stock.Controllers
{
    /// <summary>
    /// Informe Movimientos Repartidor
    /// </summary>
    public class MovDelInfsController : Controller
    {
        private readonly IMovementRepository movementRepository;

        public MovDelInfsController()
            : this(new MovementRepository())
        {
        }

        public MovDelInfsController(IMovementRepository movementRepository)
        {
            this.movementRepository = movementRepository;
        }

        [Authorize]
        public ActionResult Index()
        {
            MovDelInfViewModels vm = new MovDelInfViewModels();
            vm.DateFrom = vm.HrFrom = SiteMethods.GetDateFrom(DateTime.Now, null);
            vm.DateTo = vm.HrTo = SiteMethods.GetDateTo(DateTime.Now, null);
            return View(vm);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Filtrar(MovDelInfViewModels vm)
        {
            vm.DateFrom = SiteMethods.GetDateFrom(vm.DateFrom, vm.HrFrom);
            vm.DateTo = SiteMethods.GetDateTo(vm.DateTo, vm.HrTo);

            if (ModelState.IsValid)
            {
                vm.InfList = movementRepository.sp_MovDelivery(vm);
                if (vm.InfList.Count >= SiteConsts.RowMax)
                    ViewBag.MaxRows = String.Format("Su filtro de búsqueda trajo {0} o más registros", SiteConsts.RowMax);
            }

            return PartialView("_List", vm.InfList);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                movementRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
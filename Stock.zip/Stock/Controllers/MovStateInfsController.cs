using Stock.Infrastructure;
using Stock.Models;
using System;
using System.Web.Mvc;

namespace Stock.Controllers
{
    public class MovStateInfsController : Controller
    {
        private readonly IMovementRepository movementRepository;

        // If you are using Dependency Injection, you can delete the following constructor
        public MovStateInfsController()
            : this(new MovementRepository())
        {
        }

        public MovStateInfsController(IMovementRepository movementRepository)
        {
            this.movementRepository = movementRepository;
        }

        [Authorize]
        public ActionResult Index()
        {
            // cuando se accede a la p�gina la lista y el filtro est�n vac�os
            MovStateInfViewModels entity = new MovStateInfViewModels();
            entity.DateFrom = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            entity.DateTo = DateTime.Now;

            return View(entity);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Filtrar(MovStateInfViewModels viewmodel)
        {
            if (ModelState.IsValid)
            {
                viewmodel = movementRepository.MovStateInf(viewmodel);
                if (viewmodel.InfList.Count == SiteConsts.RowMax)
                    ViewBag.MaxRows = String.Format("Su filtro de b�squeda trajo {0} o m�s registros", SiteConsts.RowMax);
            }

            return PartialView("_List", viewmodel.InfList);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                movementRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}


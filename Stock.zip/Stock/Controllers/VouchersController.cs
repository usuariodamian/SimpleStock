using Stock.Infrastructure;
using Stock.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Stock.Controllers
{
    [Authorize(Roles = "ADMIN,DUE")]
    public class VouchersController : Controller
    {
        private readonly IBusinessEntityRepository businessentityRepository;
        private readonly IVoucherRepository voucherRepository;
        private readonly IUserRepository userRepository;
        private readonly ICostCenterRepository costCenterRepository;
        private readonly Guid UserRep = new Guid(SiteConsts.EntRepGuid);

        // If you are using Dependency Injection, you can delete the following constructor
        public VouchersController() : this(new BusinessEntityRepository(), new VoucherRepository(), new UserRepository(), new CostCenterRepository())
        {
        }

        public VouchersController(IBusinessEntityRepository bRepository, IVoucherRepository vRepository, IUserRepository uRepository, ICostCenterRepository cRepository)
        {
            this.businessentityRepository = bRepository;
            this.voucherRepository = vRepository;
            this.userRepository = uRepository;
            this.costCenterRepository = cRepository;
        }

        public ActionResult Index()
        {
            ViewBag.PossibleBE = businessentityRepository.All.OrderBy(x => x.Name);
            ViewBag.PossibleUsers = userRepository.All.OrderBy(x => x.UserName);
            ViewBag.PossibleCC = costCenterRepository.All.OrderBy(x => x.Name);

            // cuando se accede a la p�gina la lista y el filtro est�n vac�os
            VouherViewModels vm = new VouherViewModels();
            vm.DateFrom = vm.HrFrom = SiteMethods.GetDateFrom(DateTime.Now, null);
            vm.DateTo = vm.HrTo = SiteMethods.GetDateTo(DateTime.Now, null);
            return View(vm);
        }

        [HttpPost]
        public ActionResult Filtrar(VouherViewModels vm)
        {
            vm.DateFrom = SiteMethods.GetDateFrom(vm.DateFrom, vm.HrFrom);
            vm.DateTo = SiteMethods.GetDateTo(vm.DateTo, vm.HrTo);
            if (ModelState.IsValid)
            {
                vm.ListVoucher = voucherRepository.ReadByFilter(vm);
                if (vm.ListVoucher.Count == SiteConsts.RowMin)
                    ViewBag.MaxRows = String.Format("Su filtro de b�squeda trajo {0} o m�s registros", SiteConsts.RowMin);
            }
            // devolvemos una vista parcial para renderizar la grilla
            return PartialView("_List", vm.ListVoucher);
        }

        public ViewResult Details(System.Guid id)
        {
            return View(voucherRepository.Find(id));
        }

        public ActionResult Create(bool isIn, string vd, string beId)
        {
            var voucher = new Voucher();
            voucher.IsIn = isIn;
            voucher.VouDate = DateTime.Now;

            DateTime dateMov = DateTime.Now;
            if (vd != "" && DateTime.TryParse(vd, out dateMov))
                voucher.VouDate = new DateTime(dateMov.Year, dateMov.Month, dateMov.Day, voucher.VouDate.Hour, voucher.VouDate.Minute, 0);

            Guid guidId = Guid.Empty;
            if (beId != "" && Guid.TryParse(beId, out guidId))
                voucher.BusinessEntityId = guidId;

            ViewBag.IsIn = voucher.IsIn;
            ViewBag.PossibleBusinessEntities = DropDownListGet(voucher);
            ViewBag.PossibleCosCen = costCenterRepository.All.OrderBy(x => x.Name);
            return View(voucher);
        }

        [HttpPost]
        public ActionResult Create(Voucher voucher)
        {
            if (ModelState.IsValid && Validate(voucher))
            {
                voucher.Amount = voucher.IsIn ? Math.Abs(voucher.Amount) : -Math.Abs(voucher.Amount);
                voucher.InsertUser = User.Identity.Name;
                voucherRepository.InsertOrUpdate(voucher);
                voucherRepository.Save();
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.IsIn = voucher.IsIn;
                ViewBag.PossibleBusinessEntities = DropDownListGet(voucher);
                ViewBag.PossibleCosCen = costCenterRepository.All.OrderBy(x => x.Name);
                return View();
            }
        }

        public ActionResult Edit(System.Guid id)
        {

            var voucher = voucherRepository.Find(id);
            voucher.IsIn = voucher.Amount > 0;
            voucher.Amount = Math.Abs(voucher.Amount);

            ViewBag.IsIn = voucher.IsIn;
            ViewBag.PossibleBusinessEntities = DropDownListGet(voucher);
            ViewBag.PossibleCosCen = costCenterRepository.All.OrderBy(x => x.Name);
            return View(voucher);
        }

        [HttpPost]
        public ActionResult Edit(Voucher voucher)
        {
            voucher.Amount = voucher.IsIn ? Math.Abs(voucher.Amount) : -Math.Abs(voucher.Amount);

            if (ModelState.IsValid && Validate(voucher))
            {
                voucher.UpdateUser = User.Identity.Name;
                voucherRepository.InsertOrUpdate(voucher);
                voucherRepository.Save();
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.IsIn = voucher.IsIn;
                ViewBag.PossibleBusinessEntities = DropDownListGet(voucher);
                ViewBag.PossibleCosCen = costCenterRepository.All.OrderBy(x => x.Name);
                return View();
            }
        }

        public ActionResult Delete(System.Guid id)
        {
            return View(voucherRepository.Find(id));
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(System.Guid id)
        {
            string msj = voucherRepository.DeleteVoucher(id, User.Identity.Name);
            ModelState.AddModelError(String.Empty, msj);

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                businessentityRepository.Dispose();
                voucherRepository.Dispose();
                userRepository.Dispose();
                costCenterRepository.Dispose();
            }
            base.Dispose(disposing);
        }

        public virtual JsonResult Generate(string id, string number, string ccId)
        {
            Guid EntityId = new Guid(id);
            Guid CostCenterId = new Guid(ccId);
            var resp = voucherRepository.GenerateVoucher(EntityId, number, CostCenterId, User.Identity.Name);

            return Json(new { success = true, msg = String.Format("{0}", resp) });
        }

        public virtual JsonResult GenerateAgainst(string id, string amount)
        {
            string resp = string.Empty;
            Guid EntityId = new Guid(id);
            decimal outAmount = 0;

            if (String.IsNullOrEmpty(amount)) amount = "0";

            if (Decimal.TryParse(amount, out outAmount))
                resp = voucherRepository.GenerateAgainstVoucher(EntityId, outAmount, User.Identity.Name);
            else
                resp = $"El monto ingresado no es un n�mero v�lido {amount}.";

            return Json(new { success = true, msg = resp });
        }

        /// <summary>
        /// Genera lso contracomprobantes de los comprobantes seleccionados por el monto total
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public virtual JsonResult GenerateChecked(string[] checkeds)
        {
            int selected = 0;
            Guid Id;
            foreach (var item in checkeds)
            {
                if (Guid.TryParse(item, out Id))
                {
                    voucherRepository.GenerateAgainstVoucher(Id, 0, User.Identity.Name);
                    selected++;
                }
            }
            string resp = $"Se generaron {selected} comprobantes.";

            return Json(new { success = true, msg = resp });
        }

        public virtual ActionResult GenerateAllVoucher()
        {
            var list = voucherRepository.sp_VouAllGenerate();

            return PartialView("_ConsultAllVoucher", list);
        }

        [HttpPost]
        [Authorize(Roles = "ADMIN")]
        public virtual JsonResult GenerateAllVoucher(string ccId)
        {
            string resp = "Error: no se reconoce el Centro de Costo";
            Guid CostCenterId = Guid.Empty;

            if (ccId != string.Empty && Guid.TryParse(ccId, out CostCenterId))
                resp = voucherRepository.GenerateAllVoucher(CostCenterId, User.Identity.Name);

            return Json(new { success = true, msg = resp });
        }

        /// <summary>
        /// Realiza todas las validaciones
        /// </summary>
        /// <param name="inVal"></param>
        /// <returns></returns>
        private Boolean Validate(Voucher inVal)
        {
            Boolean flag = true;
            DateTime today = DateTime.Now;

            //if (inVal.VouDate <= today.AddDays(-30) || inVal.VouDate >= today.AddDays(30))
            //{
            //    ModelState.AddModelError(String.Empty, $"No se pueden guardar un comprobante con m�s de un mes de diferencia a la fecha actual {today:dd/MM/yyyy}.");
            //    flag = false;
            //}

            if (UserRep == inVal.BusinessEntityId)
            {
                ModelState.AddModelError(String.Empty, $"No se puede generar un comprobante para la entidad Repartidor.");
                flag = false;
            }

            return flag;
        }

        List<BusinessEntity> DropDownListGet(Voucher vou)
        {
            var list = new List<BusinessEntity>();
            if (vou.BusinessEntityId != Guid.Empty)
                list.Add(businessentityRepository.Find(vou.BusinessEntityId));
            else
                list = businessentityRepository.All.OrderBy(x => x.Name).ToList();

            return list;
        }
    }
}


﻿using Stock.Infrastructure;
using Stock.Models;
using System;
using System.Web.Mvc;

namespace Stock.Controllers
{
    public class VouEntExiInfsController : Controller
    {
        private readonly IVoucherRepository voucherRepository;
        readonly Guid EntityAsj = new Guid(SiteConsts.EntASJGuid);

        // If you are using Dependency Injection, you can delete the following constructor
        public VouEntExiInfsController() : this(new VoucherRepository())
        {
        }

        public VouEntExiInfsController(IVoucherRepository vRepository)
        {
            this.voucherRepository = vRepository;
        }

        [Authorize]
        public ActionResult Index()
        {
            var entity = new VouEntExiViewModels();
            entity.DateFrom = DateTime.Now;
            entity.DateTo = DateTime.Now;
            return View(entity);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Filtrar(VouEntExiViewModels vm)
        {
            vm.DateFrom = SiteMethods.GetDateFrom(vm.DateFrom, null);
            vm.DateTo = SiteMethods.GetDateTo(vm.DateTo, null);

            if (ModelState.IsValid)
            {
                if (vm.PreviousBalance)
                {
                    decimal total = voucherRepository.sp_VouEntryExitTotal(vm.DateFrom);
                    var initial = new VouEntExiInf
                    {
                        Id = Guid.NewGuid(),
                        BusinessEntityId = EntityAsj,
                        VouDate = vm.DateFrom,
                        BusinessEntity = "Saldo anterior",
                        CostCenter = "-",
                        Number = "",
                        InsertUser = "",
                        Amount = total
                    };
                    vm.InfList.Add(initial);
                }

                vm.InfList.AddRange(voucherRepository.sp_VouEntryExit(vm));
                decimal sum = 0;
                foreach (var item in vm.InfList)
                {
                    item.SubTotal = sum + item.Amount;
                    sum += item.Amount;
                }

                if (vm.InfList.Count >= SiteConsts.RowMax)
                    ViewBag.MaxRows = String.Format("Su filtro de búsqueda trajo {0} o más registros", SiteConsts.RowMax);
            }
            // devolvemos una vista parcial para renderizar la grilla
            return PartialView("_List", vm.InfList);
        }

        [Authorize]
        public ViewResult Details(System.Guid id)
        {
            return View(voucherRepository.Find(id));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                voucherRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
﻿using Stock.Models;
using System.Web.Mvc;

namespace Stock.Controllers
{
    public class VouDebtInfsController : Controller
    {
        private readonly IVoucherRepository voucherRepository;

        // If you are using Dependency Injection, you can delete the following constructor
        public VouDebtInfsController() : this(new VoucherRepository())
        {
        }

        public VouDebtInfsController(IVoucherRepository vRepository)
        {
            this.voucherRepository = vRepository;
        }

        [Authorize]
        public ActionResult Index()
        {
            var vm = new VouDebtViewModels();
            vm.InfList = voucherRepository.sp_VouDebt();
            return View(vm);
        }
    }
}

using Stock.Models;
using System.Web.Mvc;

namespace Stock.Controllers
{
    [Authorize(Roles = "ADMIN")]
    public class AspNetUsersController : Controller
    {
        private readonly IAspNetUserRepository aspnetuserRepository;
        //private readonly IBusinessEntityUserRepository BusinessEntityuserRepository;

        // If you are using Dependency Injection, you can delete the following constructor
        public AspNetUsersController() : this(new AspNetUserRepository())
        {
        }

        public AspNetUsersController(IAspNetUserRepository aspnetuserRepository)
        {
            this.aspnetuserRepository = aspnetuserRepository;
        }

        //
        // GET: /AspNetUsers/

        public ViewResult Index()
        {
            return View(aspnetuserRepository.All);
        }

        //
        // GET: /AspNetUsers/Details/5

        public ViewResult Details(string id)
        {
            return View(aspnetuserRepository.Find(id));
        }

        //
        // GET: /AspNetUsers/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /AspNetUsers/Create

        [HttpPost]
        public ActionResult Create(AspNetUser aspnetuser)
        {
            if (ModelState.IsValid)
            {
                //aspnetuser.InsertUser = User.Identity.GetUserId();
                aspnetuserRepository.InsertOrUpdate(aspnetuser);
                aspnetuserRepository.Save();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        //
        // GET: /AspNetUsers/Edit/5

        public ActionResult Edit(string id)
        {
            return View(aspnetuserRepository.Find(id));
        }

        //
        // POST: /AspNetUsers/Edit/5

        [HttpPost]
        public ActionResult Edit(AspNetUser aspnetuser)
        {
            if (ModelState.IsValid)
            {
                //aspnetuser.UpdateUser = User.Identity.GetUserId();
                aspnetuserRepository.InsertOrUpdate(aspnetuser);
                aspnetuserRepository.Save();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                aspnetuserRepository.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}


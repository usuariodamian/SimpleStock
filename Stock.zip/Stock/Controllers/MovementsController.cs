using Stock.Infrastructure;
using Stock.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Stock.Controllers
{
    [Authorize]
    public class MovementsController : Controller
    {
        readonly IProductRepository productRepository;
        readonly IBusinessEntityRepository businessEntityRepository;
        readonly IMovementRepository movementRepository;
        readonly IUserRepository userRepository;
        readonly ICostCenterRepository costCenterRepository;
        readonly Guid EntityAsj = new Guid(SiteConsts.EntASJGuid);
        readonly Guid EntityRep = new Guid(SiteConsts.EntRepGuid);

        // If you are using Dependency Injection, you can delete the following constructor
        public MovementsController()
            : this(new ProductRepository(), new BusinessEntityRepository(), new UserRepository(), new MovementRepository(), new CostCenterRepository())
        {
        }

        public MovementsController(IProductRepository pRepository, IBusinessEntityRepository beRepository, IUserRepository uRepository, IMovementRepository mRepository, ICostCenterRepository ccRepository)
        {
            this.productRepository = pRepository;
            this.businessEntityRepository = beRepository;
            this.movementRepository = mRepository;
            this.userRepository = uRepository;
            this.costCenterRepository = ccRepository;
        }

        public ActionResult Index()
        {
            ViewBag.PossibleProducts = productRepository.All.OrderBy(x => x.Description);
            ViewBag.PossibleBE = businessEntityRepository.All.OrderBy(x => x.Name);
            ViewBag.PossibleUsers = userRepository.All.OrderBy(x => x.UserName);
            ViewBag.PossibleCC = costCenterRepository.All.OrderBy(x => x.Name);

            // cuando se accede a la p�gina la lista y el filtro est�n vac�os
            MovementViewModels entity = new MovementViewModels();
            entity.DateFrom = entity.HrFrom = SiteMethods.GetDateFrom(DateTime.Now, null);
            entity.DateTo = entity.HrTo = SiteMethods.GetDateTo(DateTime.Now, null);

            return View(entity);
        }

        [HttpPost]
        public async Task<ActionResult> Filtrar(MovementViewModels vm)
        {
            vm.DateFrom = SiteMethods.GetDateFrom(vm.DateFrom, vm.HrFrom);
            vm.DateTo = SiteMethods.GetDateTo(vm.DateTo, vm.HrTo);
            if (ModelState.IsValid)
            {
                vm.ListMovement = await movementRepository.ReadByFilter(vm);
                if (vm.ListMovement.Count == SiteConsts.RowMin)
                    ViewBag.MaxRows = String.Format("Su filtro de b�squeda trajo {0} o m�s registros", SiteConsts.RowMin);
            }
            return PartialView("_List", vm.ListMovement);
        }

        public ViewResult Details(System.Guid id)
        {
            return View(movementRepository.Find(id));
        }

        [ChildActionOnly]
        public ActionResult DetailByVoucher(System.Guid id)
        {
            var movs = movementRepository.ReadByVoucher(id);

            return PartialView("_ListVoucher", movs.ToList());
        }

        public ActionResult Create(bool isIn, string md, string beId)
        {
            var entity = new Movement();
            entity.IsIn = isIn;
            entity.MovDate = DateTime.Now;

            DateTime dateMov = DateTime.Now;
            if (md != "" && DateTime.TryParse(md, out dateMov))
                entity.MovDate = new DateTime(dateMov.Year, dateMov.Month, dateMov.Day, entity.MovDate.Hour, entity.MovDate.Minute, 0);

            Guid guidId = Guid.Empty;
            if (beId != "" && Guid.TryParse(beId, out guidId))
                entity.BusinessEntityId = guidId;

            var beType = isIn ? BusinessEntityType.Proveedor : BusinessEntityType.Cliente;

            ViewBag.IsIn = isIn;
            var products = productRepository.All.OrderBy(x => x.Description);
            ViewBag.PossibleProducts = products;
            entity.Price = products.First().Price;
            ViewBag.PossibleBusinessEntities = DropDownListGet(entity, beType);

            return View(entity);
        }

        [HttpPost]
        public ActionResult Create(Movement movement)
        {
            if (ModelState.IsValid && Validate(movement))
            {
                movement.Quantity = movement.IsIn ? Math.Abs(movement.Quantity) : -Math.Abs(movement.Quantity);
                movement.InsertUser = User.Identity.Name;
                movementRepository.TransactionStock(movement);
                return RedirectToAction("Index");
            }
            else
            {
                var beType = movement.IsIn ? BusinessEntityType.Proveedor : BusinessEntityType.Cliente;

                ViewBag.IsIn = movement.IsIn;
                ViewBag.PossibleProducts = productRepository.All.OrderBy(x => x.Description);
                ViewBag.PossibleBusinessEntities = DropDownListGet(movement, beType);
                return View();
            }
        }

        public ActionResult Delete(System.Guid id)
        {
            return View(movementRepository.Find(id));
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(System.Guid id)
        {
            Movement movement = movementRepository.Find(id);
            if (movement.VoucherId == null)
            {
                movement.UpdateUser = User.Identity.Name;
                movementRepository.TransactionStock(movement);
            }
            else
                ModelState.AddModelError(String.Empty, "El movimiento se encuentra asociado a un Comprobante.");



            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                productRepository.Dispose();
                movementRepository.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Realiza todas las validaciones
        /// </summary>
        /// <param name="inVal"></param>
        /// <returns></returns>
        private Boolean Validate(Movement inVal)
        {
            Boolean flag = true;
            DateTime today = DateTime.Now;

            //if (inVal.MovDate <= today.AddDays(-30) || inVal.MovDate >= today.AddDays(30))
            //{
            //    ModelState.AddModelError(String.Empty, $"No se pueden guardar un movimiento con m�s de un mes de diferencia a la fecha actual {today:dd/MM/yyyy}.");
            //    flag = false;
            //}

            if (inVal.IsIn && User.IsInRole("REP") && inVal.BusinessEntityId != EntityRep)
            {
                ModelState.AddModelError(String.Empty, "No se pueden ingresar movimientos distintos de entidad Repartidor cuando el rol del usuario es REP.");
                flag = false;
            }

            return flag;
        }

        List<BusinessEntity> DropDownListGet(Movement movement, BusinessEntityType beType)
        {
            var list = new List<BusinessEntity>();
            if (User.IsInRole("REP"))
            {
                list.Add(businessEntityRepository.Find(EntityRep));
            }
            else if (User.IsInRole("ENC"))
            {
                list.Add(businessEntityRepository.Find(EntityAsj));
            }
            else
            {
                if (movement.BusinessEntityId != Guid.Empty)
                {
                    var selected = businessEntityRepository.Find(movement.BusinessEntityId);
                    if (selected.BEType == beType) list.Add(selected);
                }
                if (list.Count == 0)
                {
                    list = businessEntityRepository.AllByBEType(beType);
                    if (beType == BusinessEntityType.Cliente)
                    {
                        var asj = businessEntityRepository.Find(EntityAsj);
                        list.Add(asj);
                        list = list.OrderBy(x => x.Name).ToList();
                    }
                }
            }
            return list;
        }
    }
}



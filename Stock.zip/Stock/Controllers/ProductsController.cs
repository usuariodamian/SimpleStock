using Stock.Models;
using System;
using System.Linq;
using System.Web.Mvc;

namespace Stock.Controllers
{
    [Authorize(Roles = "ADMIN,DUE")]
    public class ProductsController : Controller
    {
        private readonly IProductRepository productRepository;

        public ProductsController()
            : this(new ProductRepository())
        {
        }

        public ProductsController(IProductRepository productRepository)
        {
            this.productRepository = productRepository;
        }

        public ViewResult Index()
        {
            return View(productRepository.All.OrderBy(x => x.Description));
        }

        public ViewResult Details(System.Guid id)
        {
            return View(productRepository.Find(id));
        }

        public ActionResult Create()
        {
            Product product = new Product();
            product.Stock = 0;
            return View(product);
        }

        [HttpPost]
        public ActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                product.InsertUser = User.Identity.Name;
                productRepository.InsertOrUpdate(product);
                productRepository.Save();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        public ActionResult Edit(System.Guid id)
        {
            return View(productRepository.Find(id));
        }

        [HttpPost]
        public ActionResult Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                product.UpdateUser = User.Identity.Name;
                productRepository.InsertOrUpdate(product);
                productRepository.Save();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        public ActionResult Delete(System.Guid id)
        {
            if (productRepository.HasRelationship(id))
            {
                ModelState.AddModelError(String.Empty, "No se pueden eliminar el producto est� relacionado a un movimiento.");
                ViewBag.IsRelationated = "1";
            }

            return View(productRepository.Find(id));
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(System.Guid id)
        {
            productRepository.Delete(id);
            productRepository.Save();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                productRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}


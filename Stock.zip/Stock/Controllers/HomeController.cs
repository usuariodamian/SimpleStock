﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Stock.Models;

namespace Stock.Controllers
{
    public class HomeController : Controller
    {
        private readonly IMovementRepository movementRepository;

        // If you are using Dependency Injection, you can delete the following constructor
        public HomeController()
            : this(new MovementRepository())
        {
        }

        public HomeController(IMovementRepository movementRepository)
        {
            this.movementRepository = movementRepository;
        }

        public ActionResult Index()
        {
            Product prod = new Product();

            //if (Request.IsAuthenticated)
            //    prod = movementRepository.ProductivityGet(DateTime.Now);

            return View(prod);
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Puedes ubicarnos.";

            return View();
        }
    }
}
﻿using Stock.Models;
using System.Linq;
using System.Web.Mvc;

namespace Stock.Controllers
{
    public class ProStockInfsController : Controller
    {
        private readonly IProductRepository pRepository;

        public ProStockInfsController(): this(new ProductRepository()){}

        public ProStockInfsController(IProductRepository productRepository)
        {
            this.pRepository = productRepository;
        }

        [Authorize]
        public ViewResult Index()
        {
            return View(pRepository.All.OrderBy(x => x.Description));
        }
    }
}
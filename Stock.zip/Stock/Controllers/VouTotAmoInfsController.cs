using Stock.Infrastructure;
using Stock.Models;
using System;
using System.Linq;
using System.Web.Mvc;

namespace Stock.Controllers
{
    public class VouTotAmoInfsController : Controller
    {
        private readonly IBusinessEntityRepository businessentityRepository;
        private readonly IVoucherRepository voucherRepository;

        // If you are using Dependency Injection, you can delete the following constructor
        public VouTotAmoInfsController() : this(new BusinessEntityRepository(), new VoucherRepository())
        {
        }

        public VouTotAmoInfsController(IBusinessEntityRepository bRepository, IVoucherRepository vRepository)
        {
            this.businessentityRepository = bRepository;
            this.voucherRepository = vRepository;
        }

        [Authorize]
        public ActionResult Index()
        {
            //si es un repartidos solo debe mostrar cargar el combo de CLIENTES
            if (User.IsInRole("REP"))
            {
                ViewBag.PossibleBE = businessentityRepository.AllByBEType(BusinessEntityType.Cliente);
            }
            else
            {
                ViewBag.PossibleBE = businessentityRepository.All.OrderBy(x => x.Name);
            }

            return View();
        }

        [Authorize]
        [HttpPost]
        public ActionResult Filtrar(VouTotAmoViewModels vm)
        {
            if (ModelState.IsValid)
            {
                vm.InfList = voucherRepository.sp_VouTotalAmount(vm);
                if (vm.InfList.Count >= SiteConsts.RowMin)
                    ViewBag.MaxRows = String.Format("Su filtro de b�squeda trajo {0} o m�s registros", SiteConsts.RowMin);
            }
            // devolvemos una vista parcial para renderizar la grilla
            return PartialView("_List", vm.InfList);
        }

        [Authorize]
        public ViewResult Details(System.Guid id)
        {
            return View(voucherRepository.Find(id));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                businessentityRepository.Dispose();
                voucherRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}


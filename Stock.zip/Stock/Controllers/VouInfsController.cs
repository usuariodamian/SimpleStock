using Stock.Infrastructure;
using Stock.Models;
using System;
using System.IO;
using System.Linq;
using System.Web.Mvc;

namespace Stock.Controllers
{
    [Authorize(Roles = "ADMIN,DUE")]
    public class VouInfsController : Controller
    {
        private readonly IBusinessEntityRepository businessentityRepository;
        private readonly IVoucherRepository voucherRepository;
        private readonly ICostCenterRepository costCenterRepository;

        // If you are using Dependency Injection, you can delete the following constructor
        public VouInfsController() : this(new BusinessEntityRepository(), new VoucherRepository(), new CostCenterRepository())
        {
        }

        public VouInfsController(IBusinessEntityRepository bRepository, IVoucherRepository vRepository, ICostCenterRepository cRepository)
        {
            this.businessentityRepository = bRepository;
            this.voucherRepository = vRepository;
            this.costCenterRepository = cRepository;
        }

        [Authorize]
        public ActionResult Index()
        {
            ViewBag.PossibleBE = businessentityRepository.All.OrderBy(x => x.Name);
            ViewBag.PossibleCC = costCenterRepository.All.OrderBy(x => x.Name);

            VouInfViewModels entity = new VouInfViewModels();
            entity.DateFrom = SiteMethods.GetDateFrom(DateTime.Now, null);
            entity.HrFrom = entity.DateFrom;
            entity.DateTo = SiteMethods.GetDateTo(DateTime.Now, null);
            entity.HrTo = entity.DateTo;
            return View(entity);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Filtrar(VouInfViewModels vm)
        {
            vm.DateFrom = SiteMethods.GetDateFrom(vm.DateFrom, vm.HrFrom);
            vm.DateTo = SiteMethods.GetDateTo(vm.DateTo, vm.HrTo);

            if (ModelState.IsValid)
            {
                if (vm.BusinessEntityId == null)
                    vm.BusinessEntityId = Guid.Empty;
                if (vm.CostCenterId == null)
                    vm.CostCenterId = Guid.Empty;
                vm.ListVoucher = voucherRepository.sp_Voucher(vm);
                if (vm.ListVoucher.Count >= SiteConsts.RowMax)
                    ViewBag.MaxRows = String.Format("Su filtro de b�squeda trajo {0} o m�s registros", SiteConsts.RowMax);
            }
            // devolvemos una vista parcial para renderizar la grilla
            return PartialView("_List", vm.ListVoucher);
        }

        [HttpPost]
        public virtual JsonResult Export(VouInfViewModels vm)
        {
            string csvName = this.ControllerContext.RouteData.Values["controller"].ToString();
            string serverMapPath = Server.MapPath("~/App_Data/" + csvName + ".csv");

            FileInfo file = new FileInfo(serverMapPath);
            if (file.Exists)
            {
                file.Delete();
                file = new FileInfo(serverMapPath);
            }

            vm.DateFrom = SiteMethods.GetDateFrom(vm.DateFrom, vm.HrFrom);
            vm.DateTo = SiteMethods.GetDateFrom(vm.DateTo, vm.HrTo);
            vm.BusinessEntityId = vm.BusinessEntityId ?? Guid.Empty;
            vm.CostCenterId = vm.CostCenterId ?? Guid.Empty;

            var result = voucherRepository.sp_Voucher(vm);

            using (var w = new StreamWriter(serverMapPath))
            {
                w.WriteLine("sep=;");
                w.WriteLine("Fecha;Entidad;Cent.Costo;Numero;Descripcion;Monto");
                foreach (var item in result)
                {
                    w.WriteLine($"{item.VouDate};{item.BusinessEntity};{item.CostCenter};{item.Number};{item.Description};{item.Amount}");
                    w.Flush();
                }
            }

            return Json(new
            {
                result = serverMapPath,
                success = true
            });
        }

        public virtual FileResult DownloadCSV(string file)
        {
            byte[] fileBytes = System.IO.File.ReadAllBytes(file);
            var fileDownloadName = $"InfComp{DateTime.Now:yyMMdd_hhmmss}.csv";
            const string contentType = "text/csv";
            return File(fileBytes, contentType, fileDownloadName);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                businessentityRepository.Dispose();
                voucherRepository.Dispose();
                costCenterRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}


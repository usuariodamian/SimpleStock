using Stock.Infrastructure;
using Stock.Models;
using System;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace Stock.Controllers
{
    [Authorize(Roles = "ADMIN,DUE")]
    public class BusinessEntitiesController : Controller
    {
        private readonly IBusinessEntityRepository beRepository;

        // If you are using Dependency Injection, you can delete the following constructor
        public BusinessEntitiesController() : this(new BusinessEntityRepository())
        {
        }

        public BusinessEntitiesController(IBusinessEntityRepository businessentityRepository)
        {
            this.beRepository = businessentityRepository;
        }

        public ViewResult Index()
        {
            var vm = new BusEntViewModels() { Active = true };
            return View(vm);
        }

        [HttpPost]
        public ActionResult Filtrar(BusEntViewModels vm)
        {
            if (ModelState.IsValid)
            {
                vm.List = beRepository.ReadByFilter(vm);
                if (vm.List.Count == SiteConsts.RowMin)
                    ViewBag.MaxRows = $"Su filtro de b�squeda trajo {SiteConsts.RowMin} o m�s registros";
            }
            // devolvemos una vista parcial para renderizar la grilla
            return PartialView("_List", vm.List);
        }

        public ViewResult Details(Guid id)
        {
            return View(beRepository.Find(id));
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(BusinessEntity businessentity)
        {
            if (ModelState.IsValid)
            {
                businessentity.InsertUser = User.Identity.Name;
                beRepository.InsertOrUpdate(businessentity);
                beRepository.Save();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        public ActionResult Edit(Guid id)
        {
            return View(beRepository.Find(id));
        }

        [HttpPost]
        public ActionResult Edit(BusinessEntity businessentity)
        {
            if (ModelState.IsValid)
            {
                businessentity.UpdateUser = User.Identity.Name;
                beRepository.InsertOrUpdate(businessentity);
                beRepository.Save();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        public ActionResult Delete(Guid id)
        {
            return View(beRepository.Find(id));
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(Guid id)
        {
            beRepository.Delete(id);
            beRepository.Save();

            return RedirectToAction("Index");
        }

        public FileContentResult DownloadCSV()
        {
            DateTime printDate = DateTime.Now;
            string fileName = $"Entidades{printDate:yyMMdd_hhmmss}.csv";
            var csv = new StringBuilder();
            csv.AppendLine("sep=;");
            csv.AppendLine("Nombre;Tipo;CUIT;Descripcion;Telefono;Email;Activo;Direccion");

            foreach (var item in beRepository.All.OrderBy(n => n.Name))
            {
                csv.AppendLine($"{item.Name};{item.BEType};{item.CUIT};{item.Description};{item.Phone};{item.Email};{item.Active};{item.Address}");
            }

            return File(new UTF8Encoding().GetBytes(csv.ToString()), "text/csv", fileName);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                beRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

